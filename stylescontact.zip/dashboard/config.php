<?php
$servername = "localhost"; // Serverul MySQL, de obicei 'localhost' pe Bluehost
$username = "brqzqcmy_cars"; // Numele de utilizator MySQL pe care l-ai configurat (de exemplu, 'brqzqcmy_WPT7T')
$password = "ADawidE2003@"; // Parola pentru utilizatorul respectiv
$dbname = "brqzqcmy_cars"; // Numele bazei de date pe care ai creat-o, adică 'brqzqcmy_cars'


// Crează conexiunea
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Verifică conexiunea
if (!$conn) {
    die("Conexiune eșuată: " . mysqli_connect_error());
}
?>
